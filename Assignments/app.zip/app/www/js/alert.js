function checkAndAdd(argument) {
  var nameObj = document.getElementById("user-name"),
  numberObj = document.getElementById("user-number"),
  imageObj = document.getElementById("user-image");
  var name = nameObj.value,
  number=numberObj.value,
  image = imageObj.value;
  if(!name||!number)
    alert("error");
  addContact(name,number,image);
  alert("success")
  nameObj.value="";
  numberObj.value = "";
  imageObj.value = "";
} 